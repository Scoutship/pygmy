from typing import Union, List, Optional
from engine_database.redis.client import redis_client


async def publish_message(stream: str, entry: dict, max_len: int = 100000, message_id: str = '*') -> str:
    return await redis_client.xadd(name=stream, entry=entry, max_len=max_len, stream_id=message_id)


async def delete_message(stream: str, message_id: str) -> int:
    return await redis_client.xdel(name=stream, stream_id=message_id)


async def ack_read_message(stream: str, group: str, message_id: str) -> int:
    return await redis_client.xack(name=stream, group=group, stream_id=message_id)


async def transfer_pending_message(stream: str, group: str, to_consumer: str,
                                   min_idle_time: int, message_ids: List[str]):
    return await redis_client.xclaim(name=stream, group=group, consumer=to_consumer,
                                     min_idle_time=min_idle_time, stream_ids=message_ids)


async def create_consumer_group(stream: str, group: str, start_id: Union[int, str] = 0) -> bool:
    """
    start_id == '$' means start from newest message id
    """
    return await redis_client.xgroup_create(name=stream, group=group, stream_id=start_id)


async def consumer_group_set_latest_id(stream: str, group: str, message_id: str) -> bool:
    return await redis_client.xgroup_set_id(name=stream, group=group, stream_id=message_id)


async def consumer_groups_for_stream(stream: str) -> list:
    """
    [{'name': 'group_name', 'consumers': 2, 'pending': 29, 'last-delivered-id': '1620721684907-0'}]
    """
    return await redis_client.xinfo_groups(stream)


async def consumer_group_info(group: str, stream: str) -> Optional[dict]:
    """
    {'name': 'group_name', 'consumers': 2, 'pending': 29, 'last-delivered-id': '1620721684907-0'}
    """
    groups = await consumer_groups_for_stream(stream)
    for g in groups:
        if g['name'] == group:
            return g
    return None


async def read_messages_by_group(group: str, consumer: str, stream: str, stream_id: str = '>',
                                 count: int = 1, block: int = None):
    """
    stream: format is {stream_name: stream_message_id}
        stream_id: 在客户端消费者读取Stream消息时，Redis服务器将消息回复给客户端的过程中，客户端突然断开了连接，消息就丢失了。
                   但是PEL里已经保存了发出去的消息ID。待客户端重新连上之后，可以再次收到PEL中的消息ID列表。
                   不过此时xreadgroup的起始消息ID不能为参数 ">"，而必须是任意有效的消息ID，
                   一般将参数设为 '0-0'，表示读取所有的PEL消息以及自last_delivered_id之后的新消息

    block: number of milliseconds to wait, if nothing already present
    noack: do not add messages to the PEL(pending message list)
    """
    return await redis_client.xreadgroup(group=group, consumer_id=consumer, count=count,
                                         block=block, **{stream: stream_id})


async def read_messages_from_pending(stream: str, group: str, start: str = '-',
                                     end: str = '+', count: int = None, consumer: str = None) -> list:
    return await redis_client.xpending(name=stream, group=group, start=start, end=end, count=count, consumer=consumer)
