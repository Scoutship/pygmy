from engine_database.mongo.client import CorsairScouts
from engine_oiler.navigator.url_meta import UrlMeta


async def insert_meta(info: UrlMeta):
    return await CorsairScouts.WebMeta.collection.update_one({"url": info.url},
                                                           {"$set": info.dict(exclude_none=True, exclude_unset=True)},
                                                           upsert=True)
