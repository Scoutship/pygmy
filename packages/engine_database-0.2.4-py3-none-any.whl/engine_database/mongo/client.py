from motor.motor_asyncio import AsyncIOMotorClient
from enum import Enum

from engine_database import config

mongo_client = AsyncIOMotorClient(config.mongo_uri)


class DataBase(str, Enum):
    CorsairCabin = 'corsair_cabin'  # 所有资源的存储空间
    CorsairScouts = 'corsair_scouts'  # 网站导航信息
    CorsairMission = 'corsair_mission'  # 任务管理

    @property
    def database(self):
        return mongo_client[self.value]


class CollectionBase(str):
    @property
    def database(self):
        pass

    @property
    def collection(self):
        return self.database[self.value]


class CorsairCabin(CollectionBase, Enum):
    TagDrafts = 'tag_drafts'
    EngineProgress = 'engine_progress'  # 爬取进度
    TelegramEntryResource = 'telegram_entry_resource'  # Telegram 待爬取资源：channel link

    AssetsCollection = 'assets_collections'  # 资源合集
    AssetsSource = 'assets_source'  # 资源来源
    AssetsMedia = 'assets_medias'  # 资源媒体
    AssetsFilters = 'assets_filters'  # 资源过滤词

    BlackList = 'blacklist_collection'  # 黑名单库，人工审视后加入过滤词库

    @property
    def database(self):
        return DataBase.CorsairCabin.database


class CorsairScouts(CollectionBase, Enum):
    WebMeta = 'web_meta'  # 网站 meta 信息
    TwitterMeta = 'twitter_meta'
    ScoutsItem = 'scouts_item'

    @property
    def database(self):
        return DataBase.CorsairScouts.database


class CorsairMission(CollectionBase, Enum):
    SchedulerJobs = 'scheduler_jobs'
    ExecutionJobs = 'execution_jobs'
    JobAuditLogs = 'job_audit_logs'

    @property
    def database(self):
        return DataBase.CorsairMission.database
