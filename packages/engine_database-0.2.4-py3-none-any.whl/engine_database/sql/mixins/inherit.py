import sqlalchemy as sa
from sqlalchemy import orm
from sqlalchemy.ext.declarative import declared_attr


@orm.declarative_mixin
class JoinedInheritBaseMixin:
    __abstract__ = True
    __type_identity__ = None
    __type_column_name__ = 'discriminator'
    __type_column_type__ = sa.String(50)

    @declared_attr
    def __mapper_args__(cls):
        return {'polymorphic_identity': cls.__type_identity__ if cls.__type_identity__ else cls.__tablename__,
                'polymorphic_on': cls.__inherit_discriminator}

    @declared_attr
    def __inherit_discriminator(cls):
        return sa.Column(cls.__type_column_name__, cls.__type_column_type__, nullable=False, index=True)


@orm.declarative_mixin
class JoinedInheritMixin:
    """
    Must be set as fist inherit class
    """
    __abstract__ = True
    __type_identity__ = None
    __inherit_key_type__ = sa.BigInteger
    __inherit_class__ = None

    @declared_attr
    def __mapper_args__(cls):
        return {
            'polymorphic_identity': cls.__type_identity__ if cls.__type_identity__ else cls.__tablename__,
            'inherit_condition': cls.id == cls.__inherit_class__.id,
            'inherit_foreign_keys': cls.id,
        }

    @declared_attr
    def id(cls):
        # return cls.__inherit_class__.__table__.c.get('id', sa.Column(cls.__inherit_key_type__))
        return sa.Column('id', cls.__inherit_key_type__, primary_key=True)

    @declared_attr
    def __map_parent_id(cls):
        return orm.column_property(cls.id, cls.__inherit_class__.id)