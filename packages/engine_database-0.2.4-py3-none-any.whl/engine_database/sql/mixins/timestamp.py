import sqlalchemy as sa
from sqlalchemy.orm import declarative_mixin


@declarative_mixin
class CreatedTimeMixin:
    __abstract__ = True

    __created_at_name__ = 'created_at'
    __datetime_func__ = sa.func.now()

    created_at = sa.Column(__created_at_name__,
                           sa.TIMESTAMP(timezone=False),
                           default=__datetime_func__,
                           nullable=False)


@declarative_mixin
class TimestampsMixin(CreatedTimeMixin):
    """Mixin that define timestamp columns."""
    __updated_at_name__ = 'updated_at'
    __datetime_func__ = sa.func.now()

    updated_at = sa.Column(__updated_at_name__,
                           sa.TIMESTAMP(timezone=False),
                           default=__datetime_func__,
                           onupdate=__datetime_func__,
                           nullable=False)
