import sqlalchemy as sa
from sqlalchemy import orm, cast, Integer, ARRAY
from sqlalchemy.orm import remote
from sqlalchemy.ext.declarative import declared_attr

from engine_oiler.amor.content import ContentType

from engine_database.sql.base import BaseModel, Base
from engine_database.sql.mixins import CreatedTimeMixin, SFIDMixin, UIDMixin, \
    JoinedInheritMixin, JoinedInheritBaseMixin, ObjectStatusMixin
from engine_database.sql.types import StrEnumType

from .medias import MediaAssets


class ContentEntry(CreatedTimeMixin, SFIDMixin, UIDMixin, ObjectStatusMixin, JoinedInheritBaseMixin, BaseModel):
    __type_column_name__ = 'type'
    __type_identity__ = 'BASE'
    __type_column_type__ = StrEnumType(ContentType)

    summary = sa.Column(sa.String)
    likes_count = sa.Column(sa.Integer, nullable=False, default=0)
    comments_count = sa.Column(sa.Integer, nullable=False, default=0)


content_media_association_table = sa.Table('content_media_association', Base.metadata,
    sa.Column('content_id', sa.BigInteger, primary_key=True, autoincrement=False),
    sa.Column('media_id', sa.BigInteger, primary_key=True, autoincrement=False)
)


class __ContentMediasMixin:
    __abstract__ = True

    @declared_attr
    def medias(cls):
        return orm.relationship(
            'MediaAssets',
            secondary=content_media_association_table,
            lazy='selectin',
            primaryjoin=cls.id == content_media_association_table.c.content_id,
            secondaryjoin=MediaAssets.id == content_media_association_table.c.media_id
        )


class ContentTextEntry(JoinedInheritMixin, __ContentMediasMixin, ContentEntry):
    __type_identity__ = 'TEXT'
    __inherit_class__ = ContentEntry

    title = sa.Column(sa.String)
    content = sa.Column(sa.Text, nullable=False)


class ContentImageEntry(JoinedInheritMixin, __ContentMediasMixin, ContentEntry):
    __type_identity__ = 'IMAGE'
    __inherit_class__ = ContentEntry


class ContentVideoEntry(JoinedInheritMixin, __ContentMediasMixin, ContentEntry):
    __type_identity__ = 'VIDEO'
    __inherit_class__ = ContentEntry

