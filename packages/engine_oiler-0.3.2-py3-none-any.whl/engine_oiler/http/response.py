from typing import Optional, TypeVar, Generic, List, Type

from engine_oiler.base import BaseType
from pydantic.generics import GenericModel

from .pagination import PageResponse
from .exception import ApiError


class ApiMeta(BaseType):
    id: Optional[str] = None  # 服务端生成的标示，用于场景标示，与 context 不同之处在于 context 是客户端生成并传输过来的，id是服务端生成
    context: Optional[str] = None  # 由客户端指定，服务器原样返回，用于标示某些场景，例如：通过 context 指定数据返回后更新的控件
    method: Optional[str] = None  # 标示将要对数据执行的方法，常用于 JSON RPC
    params: Optional[str] = None  # 标示将要对数据执行方法的参数


class MetaResponse(BaseType):
    meta: Optional[ApiMeta] = None


ResponseDataType = TypeVar('ResponseDataType')


class ResultResponse(MetaResponse):
    success: bool


class DataResponse(GenericModel, MetaResponse, Generic[ResponseDataType]):
    data: ResponseDataType


class ErrorResponse(MetaResponse):
    error: ApiError


class ListResponse(GenericModel, MetaResponse, Generic[ResponseDataType]):
    list: List[ResponseDataType]
    page: PageResponse
