import re
from typing import Dict, Any
from pydantic.validators import str_validator


class MimeStr(str):
    _pattern = re.compile(r"^\w+/[-+.\w]+$")

    @classmethod
    def __modify_schema__(cls, field_schema: Dict[str, Any]) -> None:
        field_schema.update(type='string', format='mime-type')

    @classmethod
    def __get_validators__(cls):
        yield str_validator
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not cls._pattern.fullmatch(v):
            raise ValueError(f'mime string: format not match mime pattern {v}')
        return v
