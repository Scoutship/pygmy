import re
from typing import List, Any
from functools import lru_cache


@lru_cache()
def __regex_compile(pattern: str):
    return re.compile(pattern, re.IGNORECASE)


def regex_contain(content: str, regex: str) -> bool:
    return bool(__regex_compile(regex).search(content))


def regex_findall(content: str, regex: str) -> List[Any]:
    return __regex_compile(regex).findall(content)


def regex_remove(content: str, regex: str):
    return __regex_compile(regex).sub('', content).strip()


def regex_replace_multi(content: str, replace_pairs: dict):
    """
    :param content: replace string
    :param replace_pairs: {"old string": "new string", "old string1": "new string2"}
    """
    rep = dict((re.escape(k), v) for k, v in replace_pairs.items())
    return __regex_compile("|".join(rep.keys())).sub(lambda m: rep[re.escape(m.group(0)).lower()], content)
