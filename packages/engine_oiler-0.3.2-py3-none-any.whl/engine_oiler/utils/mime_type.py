from mimetypes import MimeTypes

from engine_oiler.assets.assets import AssetsType


def file_mime_type(file_path):
    mime, _ = MimeTypes().guess_type(url=file_path)
    return mime


def mime_to_asset_type(mime_type: str):
    if mime_type.startswith('audio/'):
        return AssetsType.Audio
    elif mime_type.startswith('video/'):
        return AssetsType.Video
    elif mime_type.startswith('image/'):
        return AssetsType.Photo
    elif mime_type.startswith('text/') or mime_type == 'application/epub+zip':
        return AssetsType.Novel
    else:  # File
        return AssetsType.Other


def is_video_mime(mime_type: str) -> bool:
    return mime_to_asset_type(mime_type) == AssetsType.Video


def is_audio_mime(mime_type: str) -> bool:
    return mime_to_asset_type(mime_type) == AssetsType.Audio


def is_image_mime(mime_type: str) -> bool:
    return mime_to_asset_type(mime_type) == AssetsType.Photo


def is_text_mime(mime_type: str) -> bool:
    return mime_to_asset_type(mime_type) == AssetsType.Novel
