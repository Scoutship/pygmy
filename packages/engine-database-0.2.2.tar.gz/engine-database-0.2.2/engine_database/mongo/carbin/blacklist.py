from engine_database.mongo.client import CorsairCabin


async def insert_blacklist_text(text: str):
    await CorsairCabin.BlackList.collection.insert_one({"text": text})
