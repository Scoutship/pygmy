from sqlalchemy_utils import ChoiceType
from sqlalchemy import Integer, String


EnumType = ChoiceType


def IntEnumType(choices):
    return ChoiceType(choices, impl=Integer())


def StrEnumType(choices):
    return ChoiceType(choices, impl=String())
