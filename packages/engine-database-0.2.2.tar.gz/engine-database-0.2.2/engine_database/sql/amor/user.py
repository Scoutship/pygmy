import sqlalchemy as sa
from sqlalchemy import orm

from engine_oiler.utils.enum import StrEnum, auto
from engine_oiler.amor.user import UserRole, UserGender

from engine_database.sql.base import BaseModel, Base
from engine_database.sql.mixins import CreatedTimeMixin, TimestampsMixin, SFIDMixin, UIDMixin, ObjectStatusMixin
from engine_database.sql.types import StrEnumType

from .medias import MediaImageAssets


class UserAuthSource(StrEnum):
    USERNAME = auto()
    EMAIL = auto()
    PHONE = auto()
    TELEGRAM = auto()
    TWITTER = auto()
    FACEBOOK = auto()
    QICQ = auto()
    WECHAT = auto()
    WEIBO = auto()
    APPLE = auto()


class UserAuthentication(TimestampsMixin, SFIDMixin, UIDMixin, BaseModel):
    source = sa.Column(StrEnumType(UserAuthSource), name='source', index=True, nullable=False)
    identifier = sa.Column(sa.String, unique=True, nullable=False,
                           comment="phone/email/username or third-party unique identifier")
    certificate = sa.Column(sa.String, comment="password hash value or third-party token")


user_follow_association_table = sa.Table('user_follow_association', Base.metadata,
                                         sa.Column('following_uid', sa.BigInteger, primary_key=True,
                                                   autoincrement=False),
                                         sa.Column('followed_uid', sa.BigInteger, primary_key=True, autoincrement=False)
                                         )


class UserBaseInfo(TimestampsMixin, SFIDMixin, ObjectStatusMixin, BaseModel):
    username = sa.Column(sa.String, nullable=False, unique=True, index=True)
    email = sa.Column(sa.String, nullable=True, unique=True, index=True)
    phone = sa.Column(sa.String, nullable=True, unique=True, index=True)
    nickname = sa.Column(sa.String)
    birthday = sa.Column(sa.Date())
    bio = sa.Column(sa.String)
    gender = sa.Column(StrEnumType(UserGender), name='gender', server_default=UserGender.UNKNOWN.value)
    role = sa.Column(StrEnumType(UserRole), name='role', server_default=UserRole.NORMAL.value)
    language_code = sa.Column(sa.String, comment="ISO language code")

    # TODO: https://docs.sqlalchemy.org/en/14/orm/mapped_sql_expr.html#using-a-plain-descriptor
    fans_count = orm.column_property(sa.select(sa.func.count(user_follow_association_table.following_uid)).
                                     where(user_follow_association_table.followed_uid == id).
                                     correlate_except(user_follow_association_table).
                                     scalar_subquery())
    follows_count = orm.column_property(sa.select(sa.func.count(user_follow_association_table.followed_uid)).
                                        where(user_follow_association_table.following_uid == id).
                                        correlate_except(user_follow_association_table).
                                        scalar_subquery())

    # https://stackoverflow.com/a/38338593
    friends_count = orm.column_property(sa.select(sa.func.count(
        sa.case((user_follow_association_table.followed_uid == id,
                 user_follow_association_table.following_uid),
                else_=user_follow_association_table.followed_uid)))
        .where(sa.or_(
            id == user_follow_association_table.followed_uid,
            id == user_follow_association_table.following_uid
        ))
        .group_by(sa.func.least(user_follow_association_table.followed_uid, user_follow_association_table.following_uid),
                  sa.func.greatest(user_follow_association_table.followed_uid, user_follow_association_table.following_uid))
        .having(sa.func.count('*') == 2)
        .scalar_subquery())

    avatar_id = sa.Column(sa.BigInteger)
    cover_image = orm.relationship(
        'MediaImageAssets',
        uselist=False,
        lazy='joined',
        primaryjoin=avatar_id == MediaImageAssets.id,
        foreign_keys='MediaVideoAssets.avatar_id')

    background_id = sa.Column(sa.BigInteger)
    background = orm.relationship(
        'MediaImageAssets',
        uselist=False,
        lazy='select',
        primaryjoin=background_id == MediaImageAssets.id,
        foreign_keys='MediaVideoAssets.background_id')


class UserDeviceInfo(CreatedTimeMixin, SFIDMixin, UIDMixin, BaseModel):
    os = sa.Column(sa.String)
    os_version = sa.Column(sa.String)
    device = sa.Column(sa.String)
    device_model = sa.Column(sa.String)
    device_uuid = sa.Column(sa.String, nullable=False, index=True)
    user_agent = sa.Column(sa.String)
    client = sa.Column(sa.String)
    client_version = sa.Column(sa.String)
    content_region = sa.Column(sa.String)
    accept_language = sa.Column(sa.String)

# class UserLocationInfo()
# //用户位置信息
# CREATE TABLE `user_location` (
#   `uid` bigint(20) unsigned NOT NULL COMMENT '用户ID',
#   `curr_nation` varchar(10) NOT NULL DEFAULT '' COMMENT '所在地国',
#   `curr_province` varchar(10) NOT NULL DEFAULT '' COMMENT '所在地省',
#   `curr_city` varchar(10) NOT NULL DEFAULT '' COMMENT '所在地市',
#   `curr_district` varchar(20) NOT NULL DEFAULT '' COMMENT '所在地地区',
#   `location` varchar(255) NOT NULL DEFAULT '' COMMENT '具体地址',
#   `longitude` decimal(10,6) DEFAULT NULL COMMENT '经度',
#   `latitude` decimal(10,6) DEFAULT NULL COMMENT '纬度',
#   `update_time` int(11) unsigned DEFAULT '0' COMMENT '修改时间',
#   PRIMARY KEY (`uid`)
# ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户定位表'
