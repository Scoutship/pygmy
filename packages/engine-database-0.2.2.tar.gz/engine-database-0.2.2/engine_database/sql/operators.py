from typing import ClassVar
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select


class ORMOperator:
    def __init__(self, session: AsyncSession, model: ClassVar):
        self._session = session
        self._model_cls = model

    async def create(self, **kwargs):
        model = self._model_cls(**kwargs)
        self._session.add(model)
        await self._session.flush()
        return model

    async def create_all(self, *args):
        models = [self._model_cls(**row) for row in args]
        self._session.add_all(models)
        await self._session.flush()
        return models

    async def all(self):
        result = await self._session.execute(select(self._model_cls))
        return result.scalars().all()

    async def get(self, ident):
        return await self._session.get(self._model_cls, ident=ident)

    async def update(self):
        pass

    async def delete(self):
        pass


class CoreOperator:
    def __init__(self, session: AsyncSession, model: ClassVar):
        self._session = session
        self._model_cls = model

    @property
    def _table(self):
        return self._model_cls.__table__

    async def create(self, **kwargs):
        """
        :return: CursorResult
        """
        return await self._session.execute(self._table.insert(), kwargs)

    async def create_all(self, *args):
        return await self._session.execute(self._table.insert(), args)

    async def all(self):
        return await self._session.execute(select(self._model_cls))

    async def get(self, ident):
        return await self._session.get(self._model_cls, ident=ident)

    async def update(self):
        pass

    async def delete(self):
        pass
