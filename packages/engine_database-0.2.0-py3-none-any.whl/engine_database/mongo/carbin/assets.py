from bson.objectid import ObjectId

from engine_oiler.assets.assets import IMGAssets, OMGAssets, AssetsStage, AssetsOutput

from engine_database.mongo.client import CorsairCabin


async def insert_asset(assets: IMGAssets):
    result = await CorsairCabin.AssetsCollection.collection.insert_one(assets.dict())
    return str(result.inserted_id)


async def update_asset_data(asset_id: str, data: dict):
    return await CorsairCabin.AssetsCollection.collection.update_one({"_id": ObjectId(asset_id)},
                                                                     {"$set": data})


async def update_asset(assets: OMGAssets):
    return await update_asset_data(assets.o_id, assets.dict(exclude_none=True, exclude={'o_id'}, by_alias=False))


async def update_asset_output(asset_id: str, output: AssetsOutput):
    return await CorsairCabin.AssetsCollection.collection.update_one({"_id": ObjectId(asset_id)},
                                                                     {"$bit": {"output": {"or": output.value}}})


async def find_asset(asset_id: str):
    document = await CorsairCabin.AssetsCollection.collection.find_one({"_id": ObjectId(asset_id)})
    if document:
        return OMGAssets(**document)
    return None


def find_assets_by_stage(stage: AssetsStage, extra: dict = None):
    find_params = {"stage": stage}
    if extra:
        find_params = {"$and": [find_params, extra]}
    return CorsairCabin.AssetsCollection.collection.find(find_params)


def find_assets_by_output(output: AssetsOutput):
    return find_assets_by_stage(AssetsStage.Ship, {"output": {"$bitsAllClear": output.value}})


async def delete_assets(asset_id: str):
    return await CorsairCabin.AssetsCollection.collection.delete_one({"_id": ObjectId(asset_id)})
