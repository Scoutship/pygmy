from sqlalchemy import types


class SFIDType(types.TypeDecorator):
    impl = types.BigInteger

    def process_bind_param(self, value, dialect):
        if value is None:
            return value

        if not isinstance(value, int):
            value = int(value)

        return value

    def process_result_value(self, value, dialect):
        if value is None:
            return value
        if not isinstance(value, int):
            return int(value)
        return value

    @property
    def python_type(self):
        return self.impl.type.python_type
