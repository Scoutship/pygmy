from sqlalchemy import Column, BigInteger
from sqlalchemy.orm import declarative_mixin

from engine_database.sql.types import SFIDType
from engine_database.snow_flake import SnowFlakeGenerator

generator = SnowFlakeGenerator(0, 0)


@declarative_mixin
class SFIDMixin:
    __abstract__ = True

    id = Column(SFIDType, primary_key=True, autoincrement=False, default=generator.next_id)


@declarative_mixin
class UIDMixin:
    __abstract__ = True

    user_id = Column(BigInteger, index=True, nullable=False)

