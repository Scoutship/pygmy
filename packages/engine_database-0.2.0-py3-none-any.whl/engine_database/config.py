from get_docker_secret import get_docker_secret

debug = get_docker_secret('debug', cast_to=bool, default=True)

mongo_user = get_docker_secret('mongo_user', default='')
mongo_pass = get_docker_secret('mongo_pass', default='')
mongo_host = get_docker_secret('mongo_host', default='')
mongo_port = get_docker_secret('mongo_port', default=0)
mongo_uri = f"mongodb://{mongo_user}:{mongo_pass}@{mongo_host}:{mongo_port}"

redis_host = get_docker_secret('redis_host', default='127.0.0.1')
redis_pass = get_docker_secret('redis_pass', default=None)
redis_port = get_docker_secret('redis_port', default=6379)
redis_cluster = get_docker_secret('redis_cluster', cast_to=bool, default=False)
redis_db = get_docker_secret('redis_db', default=0)

# redis_dsn = f"redis://admin:{redis_pass}@{redis_host}:{redis_port}/1"


sql_type = get_docker_secret('sql_type', default='postgresql+asyncpg')
sql_user = get_docker_secret('sql_user', default='')
sql_pass = get_docker_secret('sql_pass', default='')
sql_host = get_docker_secret('sql_host', default='')
sql_port = get_docker_secret('sql_port', default=5432)
sql_db = get_docker_secret('sql_db', default='')
sql_dsn = f"{sql_type}://{sql_user}:{sql_pass}@{sql_host}:{sql_port}/{sql_db}"
