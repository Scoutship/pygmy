from datetime import datetime
from typing import Optional, List
from pydantic import Field

from engine_oiler.base import BaseType
from engine_oiler.utils.enum import PascalizeStrEnum, auto


class SchedulerExecutionStatus(PascalizeStrEnum):
    SCHEDULED = auto()
    RUNNING = auto()
    STOPPING = auto()
    STOPPED = auto()
    FAILED = auto()
    SUCCEEDED = auto()
    TIMEOUT = auto()
    SCHEDULED_ERROR = auto()


class SchedulerExecution(BaseType):
    eid: str = Field(..., alias='execution_id')
    state: SchedulerExecutionStatus
    job_id: str
    task_id: Optional[str]
    scheduled_time: datetime
    updated_time: datetime
    result: Optional[str] = None
    pid: Optional[int] = None
    hostname: Optional[str] = None
    description: Optional[str] = None


class SchedulerExecutionJob(SchedulerExecution):
    name: Optional[str] = None
    task_name: Optional[str] = None
    pub_args: List[str] = []

    month: Optional[str] = None
    day: Optional[str] = None
    week: Optional[str] = None
    day_of_week: Optional[str] = None
    hour: Optional[str] = None
    minute: Optional[str] = None
