import cchardet as chardet
import codecs
import shutil
from logging import getLogger


def decode_data_to_utf8(data):
    enc = chardet.detect(data)["encoding"]
    if not (enc == "UTF-8"):
        try:
            tmp_data = codecs.decode(data, enc)
            data = tmp_data.encode('UTF-8').decode('UTF-8')
            return data
        except LookupError as err:
            getLogger().error(f"Decode data failure: {err}")
            return data
    else:
        return data


def decode_file_to_utf8(filename):
    tmp_file = filename + ".new"
    file = open(filename, "rb").read()
    enc = chardet.detect(file)["encoding"]
    if not (enc == "UTF-8"):
        try:
            contents = None
            with codecs.open(filename, "r", enc) as f:
                with codecs.open(tmp_file, "w", "utf-8") as target_file:
                    contents = f.read()
                    target_file.write(contents)
                shutil.move(tmp_file, filename)
            return contents
        except LookupError as err:
            getLogger().error(f"Decode file {filename} failure: {err}")
            return None
    else:
        return None
