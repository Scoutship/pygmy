from typing import Union, Optional, List
from pydantic import Field
from enum import Enum

from ..base import BaseType
from ..base.mongo import MGObjectId
from .source import AssetsSource
from .series import AssetsSeries
from .medias import OAssetsMedia
from .extensions import TelegramAssetsExtension


class AssetsType(str, Enum):
    Novel = 'Novel'
    Video = 'Video'
    Audio = 'Audio'
    Photo = 'Photo'
    WebPage = 'WebPage'
    Other = 'Other'


class AssetsStage(str, Enum):
    Raw = 'Raw'
    Rough = 'Rough'
    Ship = 'Ship'


class BaseAssets(BaseType):
    url: Optional[str] = None   # webpage only
    site_name: Optional[str] = None   # webpage Only
    title: Optional[str] = None
    summary: Optional[str] = None
    stage: AssetsStage = AssetsStage.Raw
    asset_type: AssetsType
    extensions: Optional[Union[TelegramAssetsExtension]] = None


class AssetsOutput(int, Enum):
    Nothing = 0
    Telegram = 1 << 0
    Amor = 1 << 1


class IMGAssets(BaseAssets):
    source_id: str
    series_id: Optional[str] = None
    output: AssetsOutput = AssetsOutput.Nothing


class OMGAssets(IMGAssets):
    o_id: MGObjectId = Field(..., alias='_id')


class PreviewAssets(BaseAssets):
    o_id: MGObjectId = Field(..., alias='_id')
    source: Optional[AssetsSource] = None
    series: Optional[AssetsSeries] = None
    medias: List[OAssetsMedia] = []


class UpdateAssets(BaseType):
    title: Optional[str] = None
    summary: Optional[str] = None
    stage: Optional[AssetsStage] = None
