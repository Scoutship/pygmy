from typing import List

from engine_oiler.utils.enum import StrEnum, auto
from engine_oiler.base import BaseType


class FilterAction(StrEnum):
    Delete = auto()  # 删除资源
    Empty = auto()   # 清除关键字
    Review = auto()


class FilterKeywordType(StrEnum):
    Text = auto()
    Regex = auto()


class FilterItem(BaseType):
    action: FilterAction
    format: FilterKeywordType
    keyword: str
    priority: int = 10

