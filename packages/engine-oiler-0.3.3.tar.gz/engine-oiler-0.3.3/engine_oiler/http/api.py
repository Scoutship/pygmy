from engine_oiler.base import BaseType

from engine_oiler.base.status import ObjectStatus


class StatusModel(BaseType):
    status: ObjectStatus = ObjectStatus.NORMAL

