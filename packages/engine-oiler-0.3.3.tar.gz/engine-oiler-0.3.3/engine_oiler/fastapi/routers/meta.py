from typing import TYPE_CHECKING, Any, Callable, get_type_hints
import inspect
from functools import wraps
from fastapi import APIRouter

from engine_oiler.http.response import DataResponse, ListResponse, ErrorResponse


def _meta_endpoint_wrapper(endpoint: Callable[..., Any]) -> Callable:
    @wraps(endpoint)
    async def endpoint_wrapper(*args, **kwargs):
        response = await endpoint(*args, **kwargs)
        if not isinstance(response, (DataResponse, ListResponse, ErrorResponse)):
            return DataResponse(data=response)
        return response
    return endpoint_wrapper


class MetaApiRouter(APIRouter):

    def add_api_route(self, path: str, endpoint: Callable[..., Any], **kwargs: Any) -> None:
        response_model = kwargs.get("response_model", None)

        if not TYPE_CHECKING and not response_model:
            response_model = get_type_hints(endpoint).get("return")

        if response_model:
            if not inspect.isclass(response_model) or \
                    not issubclass(response_model, (DataResponse, ListResponse, ErrorResponse)):
                kwargs['response_model'] = DataResponse[response_model]

        return super().add_api_route(path, _meta_endpoint_wrapper(endpoint), **kwargs)
