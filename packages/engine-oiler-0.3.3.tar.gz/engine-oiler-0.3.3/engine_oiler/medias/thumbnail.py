from enum import Enum


class ThumbSize(int, Enum):
    Size80 = 80
    Size160 = 160
    Size320 = 320
    Size640 = 640
    Size960 = 960
    Size1280 = 1280
