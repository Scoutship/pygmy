from enum import Enum
import orjson
from pydantic import BaseModel
from humps import camelize


def _orjson_dumps(val, *, default):
    # orjson.dumps returns bytes, to match standard json.dumps we need to decode
    def _default(obj):
        if isinstance(obj, str) and not isinstance(obj, Enum):
            return str(obj)
        return default(obj)

    return orjson.dumps(val, default=_default).decode()


class BaseType(BaseModel):
    pass

    class Config:
        json_loads = orjson.loads
        json_dumps = _orjson_dumps
        alias_generator = camelize
        allow_population_by_field_name = True  # allow use field name when alias is missing
        # validate_assignment = False
