# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['engine_oiler',
 'engine_oiler.amor',
 'engine_oiler.assets',
 'engine_oiler.base',
 'engine_oiler.engine',
 'engine_oiler.fastapi',
 'engine_oiler.fastapi.dependence',
 'engine_oiler.fastapi.routers',
 'engine_oiler.http',
 'engine_oiler.logger',
 'engine_oiler.logger.handlers',
 'engine_oiler.logger.loggers',
 'engine_oiler.medias',
 'engine_oiler.navigator',
 'engine_oiler.pirate_code',
 'engine_oiler.scheduler',
 'engine_oiler.utils']

package_data = \
{'': ['*']}

install_requires = \
['orjson>=3.5.1,<4.0.0', 'pydantic>=1.8.1,<2.0.0', 'pyhumps>=1.6.1,<2.0.0']

extras_require = \
{'api': ['fastapi>=0.63.0,<0.64.0'],
 'code': ['cchardet>=2.1.7,<3.0.0'],
 'log': ['loguru>=0.5.3,<0.6.0', 'notifiers>=1.2.1,<2.0.0'],
 'url': ['cchardet>=2.1.7,<3.0.0', 'beautifulsoup4>=4.9.3,<5.0.0'],
 'zhon': ['zhon>=1.1.5,<2.0.0']}

setup_kwargs = {
    'name': 'engine-oiler',
    'version': '0.3.3',
    'description': 'Engine oiler package',
    'long_description': '# README #\n\n## Medias\n\n所有的 medias 存储在同一个位置\n## 处理 Assets\n\n使用 `Blake` 算法计算文件 hash，检查文件重复；如果重复，对比消息的 content，重复率低于70%，则将该消息描述添加到 media 对应的 asset 中\n\n## Telegram\n\ntelegram message 单独存储\n\n## 日志收集系统\n\n* https://gist.github.com/nkhitrov/a3e31cfcc1b19cba8e1b626276148c49\n* https://www.elastic.co/beats/filebeat',
    'author': 'Corsair Captain',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
