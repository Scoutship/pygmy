import sqlalchemy as sa
from sqlalchemy import orm

from engine_database.sql.base import BaseModel
from engine_database.sql.mixins import CreatedTimeMixin, SFIDMixin, UIDMixin, \
    JoinedInheritMixin, JoinedInheritBaseMixin, ObjectStatusMixin
from engine_database.sql.types import JSONType


class MediaAssets(CreatedTimeMixin, SFIDMixin, UIDMixin, ObjectStatusMixin, JoinedInheritBaseMixin, BaseModel):
    locale = sa.Column(sa.ARRAY(JSONType), nullable=False)
    mime_type = sa.Column(sa.String, index=True, nullable=False)
    file_size = sa.Column(sa.Integer, nullable=False, default=0)


class __MediaDimensionMixin:
    __abstract__ = True

    width = sa.Column(sa.Integer, nullable=False, default=0)
    height = sa.Column(sa.Integer, nullable=False, default=0)


class MediaImageAssets(JoinedInheritMixin, __MediaDimensionMixin, MediaAssets):
    __inherit_class__ = MediaAssets
    thumbnails = sa.Column(sa.ARRAY(JSONType))  # sa.Column(sa.ARRAY(sa.PickleType(pickler=ujson)))


class MediaVideoAssets(JoinedInheritMixin, __MediaDimensionMixin, MediaAssets):
    __inherit_class__ = MediaAssets
    duration = sa.Column(sa.Float, nullable=False, default=0)
    cover_id = sa.Column(sa.BigInteger)
    cover_image = orm.relationship(
        'MediaImageAssets',
        uselist=False,
        lazy='joined',
        primaryjoin=cover_id == MediaImageAssets.id,
        foreign_keys='MediaVideoAssets.cover_id')
