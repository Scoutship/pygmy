from pymongo import DESCENDING

from engine_oiler.assets.filters import FilterItem
from engine_database.mongo.client import CorsairCabin


async def insert_asset_filter(item: FilterItem):
    return await CorsairCabin.AssetsFilters.collection.insert_one(item.dict())


async def find_all_filters():
    items = []
    async for rule in CorsairCabin.AssetsFilters.collection.find().sort("priority", DESCENDING):
        items.append(FilterItem(**rule))
    return items
