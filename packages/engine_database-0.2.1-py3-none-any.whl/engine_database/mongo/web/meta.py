from engine_database.mongo.client import WebResource


async def insert_meta(info: dict):
    return await WebResource.WebMeta.collection.insert(info)
