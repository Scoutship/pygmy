import functools
import logging

from loguru import logger
from typing import TypeVar, Callable, List

from .handlers.default import LogHandler
from .handlers.intercept import InterceptHandler


_RT = TypeVar('RT')


def config_logger(handlers: List[LogHandler]):
    logger.configure(handlers=list(map(lambda x: x.handler, handlers)))


def inject_intercept_handler(loggers: List[str] = [], include_root: bool = True):
    _logger_names = [*logging.root.manager.loggerDict.keys()] if include_root else []
    _logger_names.extend(loggers)
    for name in _logger_names:
        _logger = logging.getLogger(name)
        _logger.handlers = [InterceptHandler()]


def func_log(
    func: Callable[..., _RT], *args: object, **kwargs: object  # pylint: disable=W0613
) -> Callable[..., _RT]:
    # logger = logging.getLogger(func.__module__)

    @functools.wraps(func)
    def decorator(*args: object, **kwargs: object) -> _RT:  # pylint: disable=W0613
        logger.debug('Entering: %s', func.__name__)
        result = func(*args, **kwargs)
        logger.debug(result)
        logger.debug('Exiting: %s', func.__name__)
        return result

    return decorator
