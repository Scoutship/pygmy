from typing import Optional, List
from pydantic import AnyHttpUrl
from engine_oiler.base import BaseType


class NavBase(BaseType):
    icon: Optional[str] = None
    title: str
    description: Optional[str] = None


class NavItem(NavBase):
    url: AnyHttpUrl


class NavTag(NavBase):
    items: List[NavItem]


class NavCategory(NavBase):
    tags: List[NavTag]


def __parse_blue_navigator():
    import urllib3
    from lxml.etree import HTML, HTMLParser

    http = urllib3.PoolManager()
    response = http.request('GET', 'http://like2.club/')
    content = response.data.decode('utf-8')
    doc = HTML(content, HTMLParser())

    tags = []
    for section in doc.xpath('//div[@class="meinv"]'):
        tag_name = section.xpath('.//a[1][@class="style1"]/text()')
        if not tag_name or '在线工具' in tag_name:
            continue
        items = []
        for link in section.xpath('.//li/a'):
            url = link.xpath('./@href')[0]
            # if http.request('GET', url).status != 200:
            #     print(f"url: {url} is not access, drop it!")
            #     continue
            items.append(NavItem(title=link.xpath('.//text()')[0], url=url))
        tags.append(NavTag(title=tag_name[0], items=items))
    category = NavCategory(title="网站导航", tags=tags)

    with open('./web_nav.json', 'w+') as fp:
        fp.write(category.json(exclude_none=True, exclude_unset=True))


if __name__ == '__main__':
    __parse_blue_navigator()
