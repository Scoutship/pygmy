from engine_oiler.utils.enum import StrEnum, auto


class UserGender(StrEnum):
    MALE = auto()
    FEMALE = auto()
    OTHER = auto()
    UNKNOWN = auto()


class UserRole(StrEnum):
    NORMAL = auto()
    ADMIN = auto()
    STAFF = auto()





