from pydantic import Field
from typing import Optional, List, Literal

from ..base import BaseType
from ..medias.dimension import MediaSize


class _AssetsMeta(BaseType):
    meta: str

class AssetsTextMeta(_AssetsMeta):
    meta: Literal['text'] = 'text'
    words_count: int = 0
    language_code: Optional[str] = None


class AssetsAudioMeta(_AssetsMeta):
    meta: Literal['audio'] = 'audio'
    duration: float = 0
    performer: Optional[str] = None  # 艺术家
    title: Optional[str] = None  # 标题


class AssetsVideoMeta(MediaSize, BaseType):
    meta: Literal['video'] = 'video'
    duration: float = 0
    name: str = ''

class AssetsPhotoMeta(MediaSize, BaseType):
    meta: Literal['photo'] = 'photo'

class AssetFileMeta(BaseType):
    meta: Literal['file'] = 'file'
    name: str = ''
