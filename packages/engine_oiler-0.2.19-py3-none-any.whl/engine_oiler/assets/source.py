from enum import Enum
from typing import Union, Optional
from pydantic import Field

from ..base import BaseType
from ..base.mongo import MGObjectId


class TelegramPeer(str, Enum):
    Channel = 'PeerChannel'
    Group = 'PeerGroup'
    User = 'PeerUser'


class TelegramExtension(BaseType):
    id: Union[int, str]
    peer: TelegramPeer
    username: Optional[str] = None
    bot: bool = False  # when peer is user
    phone: Optional[str] = None
    lang_code: Optional[str] = None


class AssetsSource(BaseType):
    o_id: MGObjectId = Field(..., alias='_id')
    link: Optional[str]
    title: Optional[str]
    extensions: Union[TelegramExtension]