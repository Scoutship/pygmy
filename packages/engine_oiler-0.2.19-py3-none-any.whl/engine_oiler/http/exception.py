from typing import Optional
from engine_oiler.base import BaseType


class ApiError(BaseType):
    status: int  # http status code
    message: str = ''  # show for user
    error: Optional[str] = None  # custom message type
    raw_detail: Optional[str] = None  # message raw detail, for debug
