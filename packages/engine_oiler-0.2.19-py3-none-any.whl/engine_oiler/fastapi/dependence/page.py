from engine_oiler.http.pagination import TokenPageParams


def token_page_params(limit: int = 10, before: str = None, after: str = None) -> TokenPageParams:
    return TokenPageParams(limit=limit, before=before, after=after)
