import re
from fastapi import FastAPI
from fastapi.routing import APIRoute


def simplify_operation_ids(app: FastAPI) -> None:
    """
    Base on https://github.com/dmontagu/fastapi-utils
    Simplify operation IDs so that generated clients have simpler api function names
    """
    for route in app.routes:
        if isinstance(route, APIRoute):
            method = (list(route.methods)[0]).lower()
            version = 'v1'
            matches = re.search(r"/(v.*?)/", route.path)
            if matches and len(matches.groups()) > 0:
                version = matches.groups()[0]
            route.operation_id = f"${route.name.capitalize()}${version.capitalize()}${method.capitalize()}"