from typing import Union

from ..base import BaseType


class Progress(BaseType):
    """爬取记录"""
    source: str  # 爬取的源 eg：PeerChannel(channel_id=12453235)
    record: Union[str, int]  # eg；message id and others
