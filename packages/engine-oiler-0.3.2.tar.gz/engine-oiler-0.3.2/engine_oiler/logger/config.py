from engine_oiler.base import BaseType


UVICORN_LOGS = ["uvicorn", "uvicorn.access", "uvicorn.error"]
GUNICORN_LOGS = ["gunicorn", "gunicorn.access", "gunicorn.error"]
FASTAPI_LOGS = ["fastapi"]


class LogConfig(BaseType):
    pass
