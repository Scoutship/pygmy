from enum import Enum


_PIRATE_CODE_SEP = ':'
PIRATE_CODE = 'rich'
PIRATE_REDIS = 'pirate_command'


class PirateCommand(str, Enum):
    AddAssetSource = 'aas'
    UploadAssetMedias = 'uam'
    UploadAssetMediasDone = 'uad'
    UploadMediaDone = 'umd'
    UploadMediaFile = 'umf'
    SendCopyMessage = 'sfm'

    @property
    def command(self):
        return _PIRATE_CODE_SEP.join([PIRATE_CODE, self.value, ''])

    @property
    def redis_key(self):
        return f"{PIRATE_REDIS}_{self.value}"

    @property
    def command_regex(self):
        return rf"^{self.command}.*"

    def build_command(self, asset: str) -> str:
        return f"{self.command}{asset}"

    def parse_command(self, command: str) -> str:
        if not command.startswith(self.command):
            return None
        return command.split(_PIRATE_CODE_SEP)[-1]
