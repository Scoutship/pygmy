from pydantic import AnyUrl
from datetime import timedelta
from tempfile import TemporaryDirectory
from pathlib import Path

from engine_oiler.assets.locale import MinioLocale, MinioLocaleUrl

from engine_file.minio.client import minio_client, MinioBuckets


class TempDownloader(object):
    __temp_dir = None
    __temp_path = None

    def __init__(self, locale: MinioLocale, suffix=None, prefix=None, tmp_dir=None):
        self.__suffix = suffix
        self.__prefix = prefix
        self.__dir = tmp_dir
        self.locale = locale

    def __enter__(self):
        self.__temp_dir = TemporaryDirectory(suffix=self.__suffix, prefix=self.__prefix, dir=self.__dir)
        self.__temp_path = Path(self.__temp_dir.name).joinpath(Path(self.locale.path).name)
        minio_client.fget_object(self.locale.bucket, self.locale.path, self.template_path_str)
        return self

    def __exit__(self, type, value, trace):
        if self.__temp_dir is not None:
            self.__temp_dir.cleanup()

    @property
    def template_path(self) -> Path:
        return self.__temp_path

    @property
    def template_path_str(self) -> str:
        return str(self.template_path)


def upload_file(local_path: str, bucket: MinioBuckets, to_path: str, content_type: str, metadata=None):
    result = minio_client.fput_object(bucket_name=bucket.value,
                                      file_path=local_path,
                                      content_type=content_type,
                                      object_name=to_path,
                                      metadata=metadata)
    return MinioLocale(bucket=result.bucket_name, path=result.object_name)


def download_file(locale: MinioLocale, local_path: str):
    return minio_client.fget_object(bucket_name=locale.bucket,
                                    object_name=locale.path,
                                    file_path=local_path)


def delete_file(locale: MinioLocale):
    return minio_client.remove_object(bucket_name=locale.bucket, object_name=locale.path)


def presigned_to_path(locale: MinioLocale, expires: timedelta = timedelta(days=7)) -> AnyUrl:
    return minio_client.presigned_get_object(bucket_name=locale.bucket, object_name=locale.path, expires=expires)


def presigned_to_locale(locale: MinioLocale, expires: timedelta = timedelta(days=7)) -> MinioLocaleUrl:
    return MinioLocaleUrl(expires=expires,
                          url=minio_client.presigned_get_object(bucket_name=locale.bucket, object_name=locale.path,
                                                                expires=expires))


def presigned_put_to_locale(locale: MinioLocale, expires: timedelta = timedelta(days=7)) -> AnyUrl:
    minio_client.get_presigned_url()
    return minio_client.presigned_put_object(bucket_name=locale.bucket, object_name=locale.path, expires=expires)
