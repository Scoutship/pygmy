from get_docker_secret import get_docker_secret

minio_endpoint = get_docker_secret('minio_endpoint')
minio_access_key = get_docker_secret('minio_access_key')
minio_secret_key = get_docker_secret('minio_secret_key')
minio_https = get_docker_secret('minio_https', cast_to=bool, default=True)

thumbor_secret = get_docker_secret('THUMBOR_SECRET', default='WzT0Do+ZGPH/PHs2GHMsfeRk1K1E7v/fUMPQ+B7noFw=')
