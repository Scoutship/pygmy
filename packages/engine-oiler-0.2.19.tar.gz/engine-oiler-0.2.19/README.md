# README #

## Medias

所有的 medias 存储在同一个位置
## 处理 Assets

使用 `Blake` 算法计算文件 hash，检查文件重复；如果重复，对比消息的 content，重复率低于70%，则将该消息描述添加到 media 对应的 asset 中

## Telegram

telegram message 单独存储

## 日志收集系统

* https://gist.github.com/nkhitrov/a3e31cfcc1b19cba8e1b626276148c49
* https://www.elastic.co/beats/filebeat