from typing import Union, Optional, List

from ..base import BaseType
from .locale import MinioLocale, MinioLocaleUrl


class NSFWScore(BaseType):
    drawings: float = 0  # 普通，包含动画
    neutral: float = 0  # 普通
    sexy: float = 0  # 性感，不包含生殖器
    porn: float = 0  # 色情，包含生殖器
    hentai: float = 0  # 变态


class ImageRef(BaseType):
    nsfw: NSFWScore


class VideoRefScene(ImageRef):
    locale: Union[MinioLocale, MinioLocaleUrl]
    scene_time: float
    scene_score: float


class VideoRef(BaseType):
    scenes: List[VideoRefScene]
    preview: List[Union[MinioLocale, MinioLocaleUrl]]

class TextRef(BaseType):
    keywords: Optional[List[str]] = None
    sentences: Optional[List[str]] = None


class AudioRef(TextRef):
    audio_text: Optional[str] = None
