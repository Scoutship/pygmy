from engine_oiler.utils.enum import StrEnum, auto


class ContentType(StrEnum):
    TEXT = auto()
    IMAGE = auto()
    VIDEO = auto()





