import re
from typing import Dict, Any
from pydantic.validators import str_validator


# Limit reference from https://limits.tginfo.me/en
class UsernameStr(str):
    _pattern = re.compile(r"^[a-zA-Z0-9_]{5,32}$")

    @classmethod
    def __get_validators__(cls):  # type: ignore
        yield str_validator
        yield cls.validate

    @classmethod
    def __modify_schema__(cls, field_schema: Dict) -> None:
        field_schema.update(
            type="string",
            format='username'
        )

    @classmethod
    def validate(cls, v: Any) -> str:
        if not cls._pattern.fullmatch(v):
            raise ValueError(f'username string: format not match username pattern {v}')
        return v


class PasswordStr(str):
    _pattern = re.compile(r"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d\\\(\)\.\=\[\]\{\}\|\"\'\^\?\* +-/><_`,~!$%@#£€*?&;:#%]{6,}$")

    @classmethod
    def __get_validators__(cls):  # type: ignore
        yield str_validator
        yield cls.validate

    @classmethod
    def __modify_schema__(cls, field_schema: Dict) -> None:
        field_schema.update(
            type="string",
            format='password'
        )

    @classmethod
    def validate(cls, v: Any) -> str:
        if not cls._pattern.fullmatch(v):
            raise ValueError(f'password string: format not match password pattern {v}')
        return v