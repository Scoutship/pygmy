from typing import Optional
from pydantic import validator, conint

from engine_oiler.base import BaseType


class TokenPageParams(BaseType):
    limit: conint(gt=0) = 10
    before: Optional[str] = None  # 可选项；字符串类型；表示查询从before指向的记录之前（不包括before指向的当前记录）的limit条记录
    after: Optional[str] = None  # 可选项；字符串类型；表示查询从after指向的记录之后（不包括after指向的当前记录）的limit条记录

    # Request中before、after不能并存；当 before、after 都不存在，则是第一页
    @validator('after')
    def check_before_exist(cls, v, values):
        if values.get('before', None) is not None and v is not None:
            raise ValueError('page request before and after can not both exist')
        return v


class PageResponse(BaseType):
    prev: Optional[str] = None  # 查询前一页数据的末尾位置，Request中将此值赋给before，为null时，表示没有前一页
    next: Optional[str] = None  # 查询后一页数据的起始位置，Request中将此值赋给after，为null时，表示没有后一页
    count: Optional[int] = None
