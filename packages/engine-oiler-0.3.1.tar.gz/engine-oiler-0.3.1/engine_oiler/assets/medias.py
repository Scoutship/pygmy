from typing import Union, Optional, List
from pydantic import Field

from ..base import BaseType
from ..base.mongo import MGObjectId
from ..base.mime import MimeStr
from .metadata import AssetsTextMeta, AssetsPhotoMeta, AssetsAudioMeta, AssetsVideoMeta, AssetFileMeta
from .locale import MinioLocale, MinioLocaleUrl, TelegramLocale
from .reference import ImageRef, VideoRef, AudioRef, TextRef


class IAssetsMedia(BaseType):
    locale: List[Union[MinioLocale, MinioLocaleUrl, TelegramLocale]]
    file_size: int = 0
    mime_type: MimeStr
    digest: str
    asset_ids: List[str] = []
    tag_ids: List[str] = []
    category_id: Optional[str] = None
    metadata: Optional[Union[AssetsAudioMeta, AssetsVideoMeta, AssetsPhotoMeta, AssetsTextMeta, AssetFileMeta]] = None
    reference: Optional[Union[ImageRef, VideoRef, AudioRef, TextRef]] = None

    @property
    def minio_locale(self) -> Optional[MinioLocale]:
        for locale in self.locale:
            if isinstance(locale, MinioLocale):
                return locale
        return None

    @property
    def telegram_locale(self) -> Optional[TelegramLocale]:
        for locale in self.locale:
            if isinstance(locale, TelegramLocale):
                return locale.file_id
        return None

    def telegram_locale_with_bot(self, bot: str) -> Optional[TelegramLocale]:
        for locale in self.locale:
            if isinstance(locale, TelegramLocale) and locale.bot == bot:
                return locale
        return None

    @property
    def is_video(self):
        return self.mime_type.startswith("video/")

    @property
    def is_image(self):
        return self.mime_type.startswith("image/")

    @property
    def is_audio(self):
        return self.mime_type.startswith("audio/")

    @property
    def is_text(self):
        return self.mime_type.startswith("text/") or self.mime_type == "application/epub+zip"


class OAssetsMedia(IAssetsMedia):
    o_id: MGObjectId = Field(..., alias='_id')
