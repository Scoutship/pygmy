from typing import Optional, List

from engine_oiler.base import BaseType


class UrlMeta(BaseType):
    url: str
    favicon: Optional[str] = None
    image: Optional[str] = None
    site_name: Optional[str] = None
    title: Optional[str] = None
    color: Optional[str] = None
    description: Optional[str] = None
    keywords: List[str] = []
    extra: Optional[dict] = None
