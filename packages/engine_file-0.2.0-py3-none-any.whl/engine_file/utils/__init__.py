import hashlib

# from tempfile import TemporaryDirectory
# https://python3-cookbook.readthedocs.io/zh_CN/latest/c05/p19_make_temporary_files_and_directories.html


def file_digest(path: str, batch_size: int = 4):
    hash_object = hashlib.blake2b()
    with open(path, 'rb') as open_file:
        for chunk in iter(lambda: open_file.read(1024 * batch_size), b""):
            hash_object.update(chunk)
    return hash_object.hexdigest()
