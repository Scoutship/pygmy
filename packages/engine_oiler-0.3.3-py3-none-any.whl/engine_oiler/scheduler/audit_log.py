from datetime import datetime
from typing import Optional

from engine_oiler.base import BaseType
from engine_oiler.utils.enum import PascalizeStrEnum, auto


class SchedulerAuditLogEvent(PascalizeStrEnum):
    ADDED = auto()
    MODIFIED = auto()
    DELETED = auto()
    PAUSED = auto()
    RESUMED = auto()
    CUSTOM_RUN = auto()


class SchedulerAuditLog(BaseType):
    job_id: str
    job_name: str
    event: SchedulerAuditLogEvent
    user: Optional[str] = None
    created_time: datetime
    description: Optional[str] = None

