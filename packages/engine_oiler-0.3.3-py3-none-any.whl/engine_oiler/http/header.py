from engine_oiler.base import BaseType


class RequestHeader(BaseType):
    os: str  # iOS, Android, Mac, Windows, Linux
    os_version: str
    device: str  # phone, tablet, pc
    device_model: str  # iPhone 5s ....
    device_uuid: str
    user_agent: str
    client: str
    client_version: str
    content_region: str
    accept_language: str
    sid: str  # login token
