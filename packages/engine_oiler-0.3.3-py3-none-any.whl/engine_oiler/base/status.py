from engine_oiler.utils.enum import StrEnum, auto


class ObjectStatus(StrEnum):
    NORMAL = auto()
    DELETED = auto()
    DISABLED = auto()

