from notifiers.logging import NotificationHandler
import sys
import os
from engine_oiler.base import BaseType
from typing import Literal


class LogHandler(BaseType):
    name: Literal['stand', 'file', 'telegram']
    format: str = "<level>{level: <8}</level> " \
                  "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> " \
                  " | {module} - {file} - lines {line} | " \
                  "<cyan>{name}</cyan>:" \
                  "<cyan>{function}</cyan> " \
                  "- <level>{message}</level>"
    level: str = "INFO"

    @property
    def handler(self) -> dict:
        assert False, 'log handler property must be override'


class StandLogHandler(LogHandler):
    name: Literal['stand'] = 'stand'

    @property
    def handler(self) -> dict:
        return {
            'sink': sys.stdout,
            'format': self.format,
            'level': self.level,
            'colorize': True
        }


class FileLogHandler(LogHandler):
    name: Literal['file'] = 'file'
    file_path: str
    file_name: str
    rotation: str = "100MB"
    retention: str = "30 days"

    @property
    def handler(self) -> dict:
        return {
            'sink': os.path.join(self.file_path, self.file_name+'_{time}.json'),
            'format': self.format,
            'level': self.level,
            'rotation': self.rotation,
            'retention': self.retention,
            'serialize': True
        }


class TelegramLogHandler(LogHandler):
    name: Literal['telegram'] = 'telegram'
    token: str
    chat_id: int = -1001322928827

    @property
    def handler(self) -> dict:
        return {
            'sink': NotificationHandler("telegram", defaults={'token': self.token, 'chat_id': self.chat_id}),
            'format': self.format,
            'level': "ERROR"
        }
