from ..base import BaseType


class MediaSize(BaseType):
    width: int = 0
    height: int = 0


