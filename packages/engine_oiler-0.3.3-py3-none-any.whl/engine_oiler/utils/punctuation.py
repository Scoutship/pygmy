import difflib
import string
import functools

from zhon.hanzi import punctuation


def hans_similar_ratio(str1: str, str2: str):
    return difflib.SequenceMatcher(lambda x: x == hans_punctuation() + ' ', str1, str2).quick_ratio()


@functools.lru_cache
def hans_punctuation():
    return ''.join(set(string.punctuation + punctuation))


def is_empty_str(content: str):
    return not content or not content.strip()
