
def import_from_path(path):
    """Import a module / class from a path string.
        :param str path: class path, e.g., ndscheduler.corescheduler.job
        :return: class object
        :rtype: class
        """

    components = path.split('.')
    module = __import__('.'.join(components[:-1]))
    for comp in components[1:-1]:
        module = getattr(module, comp)
    return getattr(module, components[-1])
