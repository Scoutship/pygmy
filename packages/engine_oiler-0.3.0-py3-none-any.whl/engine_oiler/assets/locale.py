from pydantic import AnyHttpUrl
from datetime import timedelta
from ..base import BaseType


class MinioLocale(BaseType):
    bucket: str
    path: str


class MinioLocaleUrl(BaseType):
    expire: timedelta = timedelta(days=7)
    url: AnyHttpUrl
    

class TelegramLocale(BaseType):
    file_id: str
    bot: str
