from typing import Optional, Union

from ..base import BaseType


class TelegramAssetsExtension(BaseType):
    tg_peer: Optional[str] = None
    tg_group_id: Optional[Union[int, str]] = None
