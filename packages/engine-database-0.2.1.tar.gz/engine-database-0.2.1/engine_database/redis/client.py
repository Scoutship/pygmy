from aredis import StrictRedis, StrictRedisCluster

from engine_database import config

if config.redis_cluster:
    redis_client = StrictRedisCluster(host=config.redis_host,
                                      password=config.redis_pass,
                                      port=config.redis_port)
else:
    redis_client = StrictRedis(host=config.redis_host,
                               password=config.redis_pass,
                               port=config.redis_port,
                               db=config.redis_db)
