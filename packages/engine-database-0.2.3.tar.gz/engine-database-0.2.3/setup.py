# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['engine_database',
 'engine_database.mongo',
 'engine_database.mongo.carbin',
 'engine_database.mongo.scouts',
 'engine_database.redis',
 'engine_database.sql',
 'engine_database.sql.amor',
 'engine_database.sql.mixins',
 'engine_database.sql.types']

package_data = \
{'': ['*']}

install_requires = \
['engine-oiler', 'get-docker-secret>=1.0.1,<2.0.0']

extras_require = \
{'mongo': ['motor>=2.3.1,<3.0.0'],
 'redis': ['aredis[hiredis]>=1.1.8,<2.0.0'],
 'sql': ['sqlalchemy-utils>=0.37.0,<0.38.0', 'alembic>=1.5.8,<2.0.0']}

setup_kwargs = {
    'name': 'engine-database',
    'version': '0.2.3',
    'description': 'Engine Database',
    'long_description': None,
    'author': 'Corsair Captain',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
