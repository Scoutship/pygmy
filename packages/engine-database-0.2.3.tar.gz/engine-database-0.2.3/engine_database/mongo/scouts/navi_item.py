from engine_database.mongo.client import CorsairScouts
from engine_oiler.navigator.item import NavigatorItem


async def insert_item(info: NavigatorItem):
    return await CorsairScouts.ScoutsItem.collection.update_one({"url": info.url},
                                                           {"$set": info.dict(exclude_none=True, exclude_unset=True)},
                                                           upsert=True)


async def find_item(link: str):
    return await CorsairScouts.ScoutsItem.collection.find_one({"url": link})
