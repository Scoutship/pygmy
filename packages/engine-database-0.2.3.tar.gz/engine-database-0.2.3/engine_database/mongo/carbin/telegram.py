from engine_database.mongo.client import CorsairCabin

from engine_oiler.assets.assets import OMGAssets


async def find_telegram_grouped_assets(peer, grouped_id):
    document = await CorsairCabin.AssetsCollection.collection.find_one({"$and": [{"extensions.tg_peer": str(peer)},
                                                                                 {"extensions.tg_group_id": grouped_id}
                                                                        ]})
    if document:
        return OMGAssets(**document)
    return None


async def find_telegram_entry_links():
    links = []
    async for resource in CorsairCabin.TelegramEntryResource.collection.find():
        links.append(resource['link'])
    return links


async def append_telegram_entry_link(peer, link):
    return await CorsairCabin.TelegramEntryResource.collection.insert_one({"peer": str(peer), "link": link})


async def delete_telegram_entry_link(link: str):
    return await CorsairCabin.TelegramEntryResource.collection.delete_one({"link": link})
