from engine_database.mongo.client import CorsairCabin


async def get_engine_progress(source):
    document = await CorsairCabin.EngineProgress.collection.find_one({"source": str(source)},
                                                                     {"_id": 0, "record": 1})
    if document:
        return document['record']
    return None


async def update_engine_progress(source, record):
    return await CorsairCabin.EngineProgress.collection.update_one({"source": str(source)},
                                                                   {"$set": {"record": record}},
                                                                   upsert=True)
