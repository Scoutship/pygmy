from bson.objectid import ObjectId

from engine_oiler.assets.medias import IAssetsMedia, OAssetsMedia

from engine_database.mongo.client import CorsairCabin


async def insert_media(info: IAssetsMedia):
    result = await CorsairCabin.AssetsMedia.collection.insert_one(info.dict())
    return str(result.inserted_id)


async def update_media(info: OAssetsMedia):
    return await CorsairCabin.AssetsMedia.collection.update_one({"_id": ObjectId(info.o_id)},
                                                                {"$set": info.dict(exclude_none=True,
                                                                                   exclude={'o_id'})})


async def find_media_by_id(media_id: str):
    document = await CorsairCabin.AssetsMedia.collection.find_one({"_id": ObjectId(media_id)})
    if document:
        return OAssetsMedia(**document)
    return None


async def find_media_by_digest(digest: str):
    document = await CorsairCabin.AssetsMedia.collection.find_one({"digest": digest})
    if document:
        return OAssetsMedia(**document)
    return None


def iter_non_processed_messages(bot_name: str):
    """
    locale contain telegram locale and not contain minio locale and no reference
    """
    return CorsairCabin.AssetsMedia.collection.find({"$and": [
        {"locale": {"$elemMatch": {"bot": bot_name, "bucket": {"$exists": False}}}},
         {"reference": {"$exists": False}}
    ]})


def find_media_by_asset(asset_id):
    return CorsairCabin.AssetsMedia.collection.find({"asset_ids": asset_id})
