from sqlalchemy.ext.declarative import declared_attr, declarative_base
from humps import decamelize

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool

from engine_database import config
from .mixins.serialize import SerializeMixin


class __Base(object):
    @declared_attr
    def __tablename__(cls):
        return decamelize(cls.__name__)


Base = declarative_base(cls=__Base)

async_engine = create_async_engine(
    config.sql_dsn,
    # poolclass=NullPool,
    future=True,
    echo=config.debug,
    # execution_options={
    #     "isolation_level": "AUTOCOMMIT"
    # }
)

async_session = sessionmaker(bind=async_engine, expire_on_commit=False, class_=AsyncSession)


# async_session = AsyncSession(async_engine, expire_on_commit=False)


async def create_all_table():
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def drop_all_table():
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


class BaseModel(Base, SerializeMixin):
    __abstract__ = True

    def __iter__(self):
        return iter(self.to_dict().items())


async def get_session() -> AsyncSession:
    async with async_session() as session:
        async with session.begin():
            yield session
