# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['engine_file', 'engine_file.aws', 'engine_file.minio', 'engine_file.utils']

package_data = \
{'': ['*']}

install_requires = \
['engine-oiler>=0.1.0,<0.2.0', 'get-docker-secret>=1.0.1,<2.0.0']

extras_require = \
{'aws': ['boto3>=1.17.56,<2.0.0'],
 'epub': ['html2text>=2020.1.16,<2021.0.0'],
 'minio': ['minio>=7.0.2,<8.0.0'],
 'text': ['cchardet>=2.1.7,<3.0.0'],
 'thumbor': ['thumbor-expire>=0.1.0,<0.2.0']}

setup_kwargs = {
    'name': 'engine-file',
    'version': '0.2.0',
    'description': 'Engine file',
    'long_description': None,
    'author': 'Corsair Captain',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
