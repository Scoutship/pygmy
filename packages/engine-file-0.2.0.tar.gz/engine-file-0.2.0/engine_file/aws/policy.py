
"""
docs: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies.html
"""
import orjson

# from typing import List, Optional, Literal, Union
# from engine_oiler.base import BaseType
#
#
# class Statement(BaseType):
#     Sid: str = None
#     Effect: Literal['Allow', 'Deny']
#     Principal: Union[str, dict] = '*'
#     NotPrincipal: Union[str, dict] = None
#     Action: Union[str, List[str]] = ""
#
#
# class Policy(BaseType):
#     Version: Literal['2012-10-17']
#     Id: Optional[str] = None
#     Statement: List[Statement]


def s3_policy_template(arn: str, action: str = 's3:PutObject'):
    """
    action s3:*  all s3 action
    """
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "PutFileObject",
                "Effect": "Allow",
                "Principal": "*",
                "Action": [action],
                "Resource": [arn]
            }
        ]
    }
