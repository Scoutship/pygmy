import collections

"""
docs: https://docs.aws.amazon.com/zh_cn/general/latest/gr/aws-arns-and-namespaces.html
code from: https://github.com/benkehoe/aws-arn
"""

_arn_tuple = collections.namedtuple('ARN', ['partition', 'service', 'region', 'account', 'resource'])


def arn_split(arn: str):
    """Return a namedtuple of the parts of the ARNs"""
    return _arn_tuple(*arn.split(':', 5)[1:])


def arn_build(resource, service='s3', region='', account='', partition='aws') -> str:
    """
    resource: my_corporate_bucket/*             某个桶下所有资源
              my_corporate_bucket/Development/*  某个桶下路径中所有资源
    """
    return 'arn:{partition}:{service}:{region}:{account}:{resource}'.format(**{
        'partition': partition,
        'service': service,
        'region': region,
        'account': account,
        'resource': resource,
    })


def arn_build_bucket(bucket: str, dir_name: str = None, file_name: str = None) -> str:
    if dir_name:
        return arn_build(f"{bucket}/{dir_name}/*")
    elif file_name:
        return arn_build(f"{bucket}/{file_name}")
    else:
        return arn_build(f"{bucket}/*")

