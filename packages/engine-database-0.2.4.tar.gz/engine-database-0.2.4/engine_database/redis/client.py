from aredis import StrictRedis, StrictRedisCluster

from engine_database import config
from engine_oiler.utils.enum import LowerStrEnum, auto


if config.redis_cluster:
    redis_client = StrictRedisCluster(host=config.redis_host,
                                      password=config.redis_pass,
                                      port=config.redis_port,
                                      decode_responses=True)
else:
    redis_client = StrictRedis(host=config.redis_host,
                               password=config.redis_pass,
                               port=config.redis_port,
                               db=config.redis_db,
                               decode_responses=True)


class RedisStream(LowerStrEnum):
    DECK_SEAMAN = auto()

    @property
    def stream(self):
        return self.value

