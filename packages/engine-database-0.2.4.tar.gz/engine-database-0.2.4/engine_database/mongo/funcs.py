from typing import Tuple, Callable
from motor.core import Collection
from pymongo import ASCENDING, DESCENDING
from bson import ObjectId

from engine_oiler.http.pagination import TokenPageParams, PageResponse


async def pagination(collection: Collection,
                     page: TokenPageParams,
                     field: str = '_id',
                     find_params: dict = {},
                     field_type: Callable = lambda arg: ObjectId(arg),
                     page_token: Callable = lambda arg: str(arg),
                     reverse: bool = True) -> Tuple:
    query = collection

    find_params = find_params
    if page.after:
        find_params.update({field: {"$gt": field_type(page.after)}})
    elif page.before:
        find_params.update({field: {"$lt": field_type(page.before)}})

    if len(find_params.keys()) > 0:
        query = query.find(find_params)
    else:
        query = query.find()

    if not reverse:
        query = query.sort(field, ASCENDING)
    else:
        query = query.sort(field, DESCENDING)

    res_list = await query.limit(page.limit + 1).to_list(page.limit + 1)

    if page.before:
        res_list.reverse()

    has_more = len(res_list) > page.limit
    if has_more:
        res_list = res_list[0:page.limit]

    prev_cursor = None
    next_cursor = None

    if len(res_list) > 0:
        first_token = page_token(dict(res_list[0])[field])
        last_token = page_token(dict(res_list[-1])[field])

        if page.after:
            prev_cursor = first_token
            if has_more:
                next_cursor = last_token
        elif page.before:
            next_cursor = first_token
            if has_more:
                prev_cursor = last_token
            res_list.reverse()
        else:  # First page
            if has_more:
                next_cursor = last_token

    return res_list, PageResponse(prev=prev_cursor, next=next_cursor)
