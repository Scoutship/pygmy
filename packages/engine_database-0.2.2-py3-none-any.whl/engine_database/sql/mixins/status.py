from sqlalchemy import Column
from sqlalchemy.orm import declarative_mixin

from engine_oiler.base.status import ObjectStatus

from engine_database.sql.types import StrEnumType


@declarative_mixin
class ObjectStatusMixin:
    __abstract__ = True

    status = Column(StrEnumType(ObjectStatus), index=True, server_default=ObjectStatus.NORMAL.value)


