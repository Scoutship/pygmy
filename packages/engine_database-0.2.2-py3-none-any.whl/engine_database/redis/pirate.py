from engine_database.redis.client import redis_client
from engine_oiler.pirate_code import PirateCommand


async def push_pirate_command_upload(command: PirateCommand, upload_id: str):
    return await redis_client.rpush(command.redis_key, upload_id)


async def pop_pirate_command_upload(command: PirateCommand, timeout: int = 10):
    return await redis_client.blpop(command.redis_key, timeout=timeout)


async def list_pirate_command_all_id(commnad: PirateCommand):
    return await redis_client.lrange(commnad.redis_key, 0, -1)
