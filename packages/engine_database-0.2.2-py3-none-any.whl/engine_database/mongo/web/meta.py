from engine_database.mongo.client import WebResource
from engine_oiler.web.meta import UrlMeta


async def insert_meta(info: UrlMeta):
    return await WebResource.WebMeta.collection.update_one({"url": info.url},
                                                           {"$set": info.dict(exclude_none=True, exclude_unset=True)},
                                                           upsert=True)
