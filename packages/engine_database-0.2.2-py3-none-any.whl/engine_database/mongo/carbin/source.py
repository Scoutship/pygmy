from engine_database.mongo.client import CorsairCabin

from engine_oiler.assets.source import AssetsSource, TelegramPeer
from bson.objectid import ObjectId


async def find_source_by_link(link: str):
    document = await CorsairCabin.AssetsSource.collection.find_one({"link": link})
    if document is None:
        return None
    return AssetsSource(**document)


async def find_source_by_id(o_id: str):
    document = await CorsairCabin.AssetsSource.collection.find_one({"_id": ObjectId(o_id)})
    if document is not None:
        document = AssetsSource(**document)
    return document


async def find_telegram_source_by_id(peer: TelegramPeer, source_id):
    document = await CorsairCabin.AssetsSource.collection.find_one({"$and": [{"extensions.peer": peer},
                                                                             {"extensions.id": int(source_id)}]})
    if document:
        return document['_id']
    return None


async def insert_source(info: AssetsSource):
    result = await CorsairCabin.AssetsSource.collection.insert_one(info.dict(exclude_none=True))
    return str(result.inserted_id)
