from urllib import request, parse
from bs4 import BeautifulSoup


class UrlMetaParser:
    def parse_meta(self, link: str):
        """Generate preview obj per link.
            1. Determine title of target url.
            2. Create description blurb of target url.
            3. Find suitable image for target url.
            4. Determine the top-level site name of target url.
            5. Create dict of fetched metadata.
            6. Return result.
            """
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600',
            'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0'
        }
        if 'http' not in link:
            link = f'http://{link}'
        response = request.urlopen(request.Request(url=link, headers=headers, method='GET'))
        content = response.read().decode('utf-8', errors='ignore')
        doc = BeautifulSoup(content, 'html.parser')
        preview_dict = {
            'title': self.get_title(doc),
            'description': self.get_description(doc),
            'image': self.get_image(doc, link),
            'favicon': self.get_favicon(doc, link),
            'site_name': self.get_site_name(doc, link),
            'keywords': self.get_keywords(doc),
            'url': link
        }
        return preview_dict

    def get_site_name(self, doc, url):
        """Attempt to get the site's base name.
        1. Check OG tags for site name.
        2. If no OG tag exists, get top-level domain from url.
        3. Return site name.
        """
        sitename = None
        if doc.find("meta", property="og:site_name"):
            sitename = doc.find("meta", property="og:site_name").get('content')
        else:
            components = self.get_domain(url).split('.')
            if len(components) <= 2:
                sitename = components[0]
            else:
                sitename = components[1]
        return sitename

    def get_domain(self, url):
        """Get site root domain name."""
        parsed_url = parse.urlparse(url)
        return parsed_url.netloc

    def get_title(self, doc):
        """Attempt to get a title.
        1. Check metadata for title tag.
        2. If doesn't exist, check page for h1 tag.
        3. Remove all text which comes after the first pipe ("|") in the title.
        4. Return title.
        """
        title = None
        if doc.title:
            title = doc.title.string
        elif doc.find("meta", property="og:title"):
            title = doc.find("meta", property="og:title").get('content')
        elif doc.find("h1"):
            title = doc.find("h1").string
        elif doc.find_all("h1"):
            title = doc.find_all("h1")[0].string
        if title:
            title = title.split('|')[0]
        return title

    def get_description(self, doc):
        """Attempt to get description.
        1. Check OG tags for description tag.
        2. If doesn't exist, check page for p tag.
        3, Return description.
        """
        description = None

        if doc.find("meta", attrs={'name': 'description'}):
            description = doc.find("meta", attrs={'name': 'description'}).get('content')
        elif doc.find("meta", property="og:description"):
            description = doc.find("meta", property="og:description").get('content')
        elif doc.find("p"):
            description = doc.find("p").string

        if description:
            description = description.strip()

        return description

    def get_keywords(self, doc):
        keywords = []
        if doc.find("meta", attrs={'name': 'keywords'}):
            keywords = doc.find("meta", attrs={'name': 'keywords'}).get('content').split(',')
        return keywords

    def get_image(self, doc, link):
        """Attempt to get image.
        1. Check OG tags for image tag.
        2. If doesn't exist, check page for img tag.
        3. If the image path is relative, make it absolute.
        4. Return image URL.
        """
        image = None
        if doc.find("meta", property="og:image"):
            image = doc.find("meta", property="og:image").get('content')
        elif doc.find_all("img", src=True):
            image = doc.find_all("img")
            if image:
                image = doc.find_all("img")[0].get('src')

        if image and 'http' not in image:
            image = parse.urljoin(link, image)
        return image

    def get_favicon(self, doc, link):
        """Attempt to get favicon."""
        favicon = None
        if doc.find("link", attrs={"rel": "icon"}):
            favicon = doc.find("link", attrs={"rel": "icon"}).get('href')
        elif doc.find("link", attrs={"rel": "shortcut icon"}):
            favicon = doc.find("link", attrs={"rel": "shortcut icon"}).get('href')
        if favicon and 'http' not in favicon:
            favicon = parse.urljoin(link, favicon)
        return favicon
