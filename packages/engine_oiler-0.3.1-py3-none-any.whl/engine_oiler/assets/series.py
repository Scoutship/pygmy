from typing import List

from ..base import BaseType


class AssetsSeries(BaseType):
    assetList: List[str] = []
