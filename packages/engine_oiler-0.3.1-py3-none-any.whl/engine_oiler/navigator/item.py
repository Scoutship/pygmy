from typing import List, Optional
from engine_oiler.base import BaseType
from engine_oiler.utils.enum import StrEnum, auto


class NavigatorType(StrEnum):
    WEB = auto()
    TELEGRAM = auto()
    TWITTER = auto()
    WEIBO = auto()


class NavigatorItem(BaseType):
    url: str
    title: str
    description: Optional[str]
    icon: Optional[str]
    category: str
    tags: List[str]
    type: NavigatorType
