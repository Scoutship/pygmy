from typing import Dict, Any


class MGObjectId(str):
    @classmethod
    def __get_validators__(cls):  # type: ignore
        yield cls.validate

    @classmethod
    def __modify_schema__(cls, field_schema: Dict) -> None:
        field_schema.update(
            examples=["5f85f36d6dfecacc68428a46", "ffffffffffffffffffffffff"],
            example="5f85f36d6dfecacc68428a46",
            type="string",
            format='ObjectId'
        )

    @classmethod
    def validate(cls, v: Any) -> str:
        if isinstance(v, (str)):
            return v
        return str(v)
