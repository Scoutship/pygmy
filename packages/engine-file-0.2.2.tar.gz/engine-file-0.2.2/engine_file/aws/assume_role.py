import orjson
import boto3
from functools import lru_cache

from engine_file import config
from .policy import s3_policy_template
from .arn import arn_build_bucket


@lru_cache()
def sts_client():
    return boto3.client('sts',
                        region_name='us-east-1',
                        endpoint_url=f"{'https' if config.minio_https else 'http'}://{config.minio_endpoint}",
                        aws_access_key_id=config.minio_access_key,
                        aws_secret_access_key=config.minio_secret_key
                        )


def assume_role(arn: str, session: str, policy: dict, duration: int = 3600):
    """
    :param arn: 资源名称 (ARN) format -> arn:partition:service:region:account-id:resource-id
            https://docs.aws.amazon.com/zh_cn/general/latest/gr/aws-arns-and-namespaces.html
    :param session: session name, any string
    :param policy: policy dict
    :param duration: duration
    :return: template auth info
    """
    response = sts_client().assume_role(
        RoleArn=arn,
        RoleSessionName=session,
        Policy=orjson.dumps(policy).decode("utf-8"),
        DurationSeconds=duration
    )
    return response.get('Credentials')


def assume_put_file(bucket: str, session: str, dir_name: str = None, duration: int = 3600):
    arn = arn_build_bucket(bucket, dir_name=dir_name)
    return assume_role(arn=arn,
                       session=session,
                       policy=s3_policy_template(arn=arn),
                       duration=duration)
