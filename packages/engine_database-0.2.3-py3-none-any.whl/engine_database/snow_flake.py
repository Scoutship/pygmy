import time


# 开始时间截 2020/01/01 00:00:00
TWEPOCH = 1577808000000
# 时间戳所占位数 41，可以使用 69.73 年
TIMESTAMP_BITS = 41

# 机器id所占的位数
WORKER_ID_BITS = 5
# 支持的最大机器id，结果是31 (这个移位算法可以很快的计算出几位二进制数所能表示的最大十进制数)
MAX_WORKER_ID = -1 ^ (-1 << WORKER_ID_BITS)

# 数据标识id所占的位数
DATA_CENTER_ID_BITS = 5
# 支持的最大数据标识id，结果是31
MAX_DATA_CENTER_ID = -1 ^ (-1 << DATA_CENTER_ID_BITS)

# 序列在id中占的位数 12
SEQUENCE_BITS = 12

# 机器ID向左移位数，等于序列位数
WORKER_ID_SHIFT = SEQUENCE_BITS
# 数据标识id向左移位数，等于序列数和机器位数
DATA_CENTER_ID_SHIFT = SEQUENCE_BITS + WORKER_ID_BITS
# 时间截向左移位数，等于序列数+机器位+数据位
TIMESTAMP_LEFT_SHIFT = SEQUENCE_BITS + WORKER_ID_BITS + DATA_CENTER_ID_BITS

# 生成序列的掩码
SEQUENCE_MASK = -1 ^ (-1 << SEQUENCE_BITS)


class SnowFlakeGenerator:
    class SnowflakeError(TypeError):
        """
        分布式ID生成算法占位符溢出异常，会导致生成ID为负数
        """
        pass

    class RuntimeError(TypeError):
        """
        运行时间错误，在此项目中当前运行时间小于上一次运行时间。出现此错误一般是本地时间被修改
        """
        pass

    def __init__(self, worker_id: int, data_center_id: int):
        """
        :param worker_id: (0~31)
        :param data_center_id: (0~31)
        """
        if TIMESTAMP_BITS + \
                SEQUENCE_BITS + \
                WORKER_ID_BITS + \
                DATA_CENTER_ID_BITS > 63:
            raise self.SnowflakeError(
                "TIMESTAMP_BIT + SEQUENCE_BIT + MACHINE_BIT + DATACENTER_BIT greater than to 63bit")

        if worker_id > MAX_WORKER_ID or worker_id < 0:
            raise self.SnowflakeError(f"worker Id can't be greater than {MAX_WORKER_ID} or less than 0")
        if data_center_id > MAX_DATA_CENTER_ID or data_center_id < 0:
            raise self.SnowflakeError(f"data center Id can't be greater than {MAX_DATA_CENTER_ID} or less than 0")

        self.worker_id = worker_id
        self.data_center_id = data_center_id
        self.last_timestamp = -1
        self.sequence = 0

    def next_id(self) -> int:
        current_timestamp = self.get_current_millis()

        # 如果当前时间小于上一次ID生成的时间戳，说明系统时钟回退过这个时候应当抛出异常
        if current_timestamp < self.last_timestamp:
            raise self.RuntimeError("Clock moved backwards.  Refusing to generate id")

        # 如果是同一时间生成的，则进行毫秒内序列
        if current_timestamp == self.last_timestamp:
            # 相同毫秒内，序列号自增
            self.sequence = (self.sequence + 1) & SEQUENCE_MASK
            # 同一秒的序列数已经达到最大， 毫秒内序列溢出
            if self.sequence == 0:
                # 阻塞到下一个毫秒,获得新的时间戳
                current_timestamp = self.get_next_millis()
        else:
            # 不同秒内，序列号为0
            self.sequence = 0

        self.last_timestamp = current_timestamp
        return ((current_timestamp - TWEPOCH) << TIMESTAMP_LEFT_SHIFT) \
               | (self.data_center_id << DATA_CENTER_ID_SHIFT) \
               | (self.worker_id << WORKER_ID_SHIFT) \
               | self.sequence

    def id_to_timestamp(self, sf_id: int):
        _id = sf_id >> TIMESTAMP_LEFT_SHIFT  # strip the lower 22 bits
        _id += TWEPOCH  # adjust for twitter epoch
        _id = _id / 1000  # convert from milliseconds to seconds
        return _id

    def get_next_millis(self) -> int:
        mills = self.get_current_millis()
        while mills <= self.last_timestamp:
            mills = self.get_current_millis()
        return mills

    def get_current_millis(self) -> int:
        return int(time.time() * 1000)
