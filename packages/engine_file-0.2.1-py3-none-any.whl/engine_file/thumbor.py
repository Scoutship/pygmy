from typing import Tuple, Optional
from thumbor_expire.crypto import CryptoURL

from engine_file.config import thumbor_secret
from engine_oiler.medias.thumbnail import ThumbSize
from engine_oiler.medias.dimension import MediaSize


def generate_image_thumbnail(image_path: str, image_size: MediaSize, target_size: ThumbSize
                             ) -> Tuple[Optional[str], Optional[MediaSize]]:
    if max(image_size.width, image_size.height) <= target_size.value:
        return None, None
    crypto = CryptoURL(thumbor_secret)

    thumb_path = ''
    to_width = 0
    to_height = 0
    if image_size.width >= image_size.height:
        thumb_path = crypto.generate_options(image_url=image_path, width=target_size.value, smart=True)
        to_width = target_size.value
        to_height = int(image_size.height * target_size.value / image_size.width)
    else:
        thumb_path = crypto.generate_options(image_url=image_path, height=target_size.value, smart=True)
        to_width = int(image_size.width * target_size.value / image_size.height)
        to_height = target_size.value

    return thumb_path, MediaSize(width=to_width, height=to_height)


# https://thumbor-video-engine.readthedocs.io/en/latest/filters.html
def generate_video_preview(video_path: str, video_size: MediaSize, target_size: ThumbSize
                           ) -> Tuple[Optional[str], Optional[MediaSize]]:
    thumb_path = ''
    to_width = 0
    to_height = 0

    crypto = CryptoURL(thumbor_secret)
    if video_size.width >= video_size.height:
        to_width = target_size.value
        video_path = f"{to_width}x{to_height}/filters:still():format(webp)/{video_path}"
        thumb_path = crypto.generate_url(video_path, 300)
        to_height = int(video_size.height * target_size.value / video_size.width)
    else:
        to_height = target_size.value
        video_path = f"{to_width}x{to_height}/filters:still():format(webp)/{video_path}"
        thumb_path = crypto.generate_url(video_path)
        to_width = int(video_size.width * target_size.value / video_size.height)

    return thumb_path, MediaSize(width=to_width, height=to_height)

